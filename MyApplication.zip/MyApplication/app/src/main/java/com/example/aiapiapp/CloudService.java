package com.example.aiapiapp;



import ai.api.android.AIConfiguration;

public class CloudService {

    public AIConfiguration service()
    {
        final AIConfiguration config = new AIConfiguration(
                "63965500cc7a4ad699b04c81884e9237",
                ai.api.AIConfiguration.SupportedLanguages.English,
                AIConfiguration.RecognitionEngine.System);
        return config;
    }

}
